export const Images = {
  LOGO: require("./stayput_logo_square.png"),
  STAY_PUT_LOGO: require("./StayPut_Logo.png"),
  FACEBOOK_ICON: require("./fb_logo.png"),
  FB_ICON: require("./facebook.png"),
  GOOGLE_ICON: require("./google.png"),
  APPLE_ICON: require("./apple.png"),
  CONTRACTOR_ICON: require("./Contractor.png"),
  DIYER_ICON: require("./DIYer.png"),
  MAP_MARKER: require("./Map-House.png"),
  MAP_STORE: require("./Map-Store.png"),
  SHARE_ICON: require("./Share-2.png"),
  STAR_ICON: require("./star.png"),
  DOLLAR_BAG: require("./sack-dollar-2.png"),
  USER_ICON: require("./user-alt.png"),
  LOGO_C: require("./logo.png"),
  LOCATION_ICON: require("./locationPermission.gif"),
  WareHouse: require('./warehouse.png')
};
